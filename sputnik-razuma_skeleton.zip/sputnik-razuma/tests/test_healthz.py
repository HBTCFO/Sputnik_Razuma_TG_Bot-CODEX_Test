def test_stub():
    assert 1 == 1
